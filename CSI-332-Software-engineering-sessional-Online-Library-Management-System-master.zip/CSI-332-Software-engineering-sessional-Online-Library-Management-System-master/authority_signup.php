<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
      <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


        <link rel="stylesheet" href="style1.css">
    </head>
    <body>
            <div class="col-md-6 login-form-1 h5">
    <div class="container">
            <p class="login-signup-text" style="font-size: 2rem; font-weight: 800;">Library Authority SignUp</p>
            <div class="input-group">
                <input type="text" placeholder="Full Name" name="name" required>
                 </div>
             <div class="input-group">
                <input type="email" placeholder="Your Email" name="email" required>
            </div>
            <div class="input-group">
                <input type="id" placeholder="Library Id" name="id" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password" required>
            </div>
            <div class="input-group">
                <input type="password" placeholder="Confirm Password" name="cpassword" required>
            </div>
            <div class="input-group">
                <input type="phone number" placeholder="Phone Number" name="phone number" required>
            </div>
            <div class="input-group">
                <button class="btn">SignUp</button>
     </div>
     <p class="login-signup-text">Have an account? <a href="index1.php">Login Here</a></p>
</div>
</body>
</html>
